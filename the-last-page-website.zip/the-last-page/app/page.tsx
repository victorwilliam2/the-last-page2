'use client';

import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowDown, ArrowLeft, ArrowRight, BookOpen, Check, ChevronDown, Clapperboard, Eye, FileText, Fingerprint, Menu, Search, ShieldQuestion, Sparkles, X } from 'lucide-react';

type Character = { name: string; role: string; description: string; initials: string; color: string };
type Line = { speaker: string; role?: string; text: string; direction?: boolean };
type Scene = { act: string; title: string; subtitle: string; lines: Line[] };

const characters: Character[] = [
  { name: 'NARRATOR', role: 'The voice of the story', description: 'Introduces each scene and guides the audience through the unfolding mystery.', initials: 'N', color: '#d5b77c' },
  { name: 'SAGE', role: 'Book Chow President', description: 'Trying to keep the gathering, the members, and the missing-page crisis under control.', initials: 'S', color: '#8f4d53' },
  { name: 'DETECTIVE SHARP', role: 'Self-appointed investigator', description: 'No badge. No forensic kit. Plenty of confidence and a suspicious mind.', initials: 'DS', color: '#87939c' },
  { name: 'MIRIAN', role: 'The talkative gossip', description: 'Always has information. Whether it is evidence is another matter entirely.', initials: 'M', color: '#b77d58' },
  { name: 'CHIBUIKE', role: 'The serious reader', description: 'Believes books deserve respect and that everybody should have done the reading.', initials: 'C', color: '#75866b' },
  { name: 'DAVID', role: 'The food lover', description: 'His heart is in the right place. His attention is usually near the food.', initials: 'D', color: '#bf8d52' },
  { name: 'VICTOR', role: 'The overconfident chef', description: 'The kitchen is supposedly under control. The evidence is still being reviewed.', initials: 'V', color: '#a75b45' },
  { name: 'CONTENT CREATOR', role: 'Social media enthusiast', description: 'Always ready to record the moment—even when the moment becomes a crisis.', initials: 'CC', color: '#9c779b' },
  { name: 'LATECOMER', role: 'Professional excuse maker', description: 'Can turn lateness into a negotiation, a philosophy, and a full explanation.', initials: 'L', color: '#6e8e9a' },
  { name: 'PHILOSOPHER', role: 'The deep thinker', description: 'Can transform any question into a journey through the meaning of life.', initials: 'P', color: '#8b83a4' },
  { name: 'QUIET MEMBER', role: 'The silent observer', description: 'Says very little, notices almost everything, and may know more than anyone suspects.', initials: 'QM', color: '#6f877c' },
  { name: 'MYSTERY GUEST', role: 'Keeper of the secret', description: 'Arrived with a surprise—and a secret that could change the whole story.', initials: 'MG', color: '#b7a27a' },
];

const scenes: Scene[] = [
  { act: 'ACT ONE', title: 'Welcome to Book Chow', subtitle: 'The gathering begins. The trouble follows.', lines: [
    { speaker: 'NARRATOR', text: 'It was Saturday afternoon in Awka, Anambra State. Twelve members of The Page Collective had gathered for Book Chow, an event designed to bring together books, food, friendship and meaningful conversations.' },
    { speaker: 'NARRATOR', text: 'The organisers had promised a beautiful afternoon. There would be food, laughter, an exciting reading session and a special announcement.' },
    { speaker: 'NARRATOR', text: 'Unfortunately, nobody had informed the food that the event was supposed to be organised.' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Good afternoon, everyone! Welcome to Book Chow, where we feed our minds, nourish our bodies and build meaningful friendships.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'Amen to the nourishing bodies part.' },
    { speaker: 'CHIBUIKE', role: 'SERIOUS READER', text: "You haven't even opened a book yet." },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'I opened the food container before leaving home. Does that count?' },
    { speaker: 'CHIBUIKE', role: 'SERIOUS READER', text: 'Absolutely not.' },
    { speaker: 'VICTOR', role: 'CHEF', text: 'Everybody should relax. The chef has arrived, and the kitchen is under control.' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'Victor, the last time you cooked, the smoke alarm became the main character.' },
    { speaker: 'VICTOR', role: 'CHEF', text: 'That was a technical misunderstanding.' },
    { speaker: 'PHILOSOPHER', role: 'DEEP THINKER', text: 'Perhaps the smoke was simply the food attempting to communicate its suffering.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: "Whatever it was communicating, I hope it has finished. I'm hungry." },
    { speaker: 'CONTENT CREATOR', role: 'SOCIAL MEDIA ENTHUSIAST', text: 'Wait, everyone! Don’t move. I need a video introduction.' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Please make it quick. We have a programme to follow.' },
    { speaker: 'CONTENT CREATOR', role: 'SOCIAL MEDIA ENTHUSIAST', text: 'Welcome to Book Chow! Twelve readers, one house, plenty of food and absolutely no possibility of disaster!' },
    { speaker: 'LATECOMER', role: 'PROFESSIONAL EXCUSE MAKER', text: "Sorry, sorry, sorry! I'm late!" },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'We noticed. The sun has moved, the food has arrived and the meeting has started.' },
    { speaker: 'LATECOMER', role: 'PROFESSIONAL EXCUSE MAKER', text: 'I had a very serious problem.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'State the nature of the problem.' },
    { speaker: 'LATECOMER', role: 'PROFESSIONAL EXCUSE MAKER', text: 'My bed refused to release me.' },
    { speaker: 'CHIBUIKE', role: 'SERIOUS READER', text: 'You are an adult.' },
    { speaker: 'LATECOMER', role: 'PROFESSIONAL EXCUSE MAKER', text: 'Exactly. I had to negotiate.' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Please sit down. We are about to begin our special reading session.' },
    { speaker: 'NARRATOR', text: "Sage picked up the club's special notebook. It contained a short mystery story written for the Book Chow gathering. Every member was supposed to read the story's final page together." },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'This notebook is important. The final page contains the conclusion to our story, and we have a special activity planned around it.' },
    { speaker: 'NARRATOR', text: 'Sage opened the notebook, turned several pages and stopped.' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Wait a minute.' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'What happened?' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Where is the last page?' },
    { speaker: 'STAGE DIRECTION', text: 'Pause for two seconds.', direction: true },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'THE LAST PAGE IS MISSING!' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'Is the food missing too?' },
    { speaker: 'CHIBUIKE', role: 'SERIOUS READER', text: 'David!' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'I’m asking because this house is beginning to look dangerous.' },
    { speaker: 'NARRATOR', text: 'Suddenly, what had been a peaceful book gathering became a room full of suspects.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'Nobody leaves this room!' },
    { speaker: 'LATECOMER', role: 'PROFESSIONAL EXCUSE MAKER', text: 'I just arrived. Can I at least leave the way I came?' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'Absolutely not.' },
    { speaker: 'CONTENT CREATOR', role: 'SOCIAL MEDIA ENTHUSIAST', text: 'This is unbelievable. Should I record?' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Please don’t turn our crisis into content!' },
    { speaker: 'CONTENT CREATOR', role: 'SOCIAL MEDIA ENTHUSIAST', text: 'So, should I record discreetly?' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'NO!' },
  ]},
  { act: 'ACT TWO', title: 'Everybody Is a Suspect', subtitle: 'The investigation begins—and nobody is helping.', lines: [
    { speaker: 'NARRATOR', text: 'Detective Sharp took control of the investigation. He had no official badge, no forensic equipment and no professional investigative experience. However, he had watched several detective films and was feeling confident.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'We are dealing with a serious literary crime. A page has disappeared, and someone in this room knows why.' },
    { speaker: 'PHILOSOPHER', role: 'DEEP THINKER', text: 'But can a page truly disappear? Or does it merely relocate itself within the universe?' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'You are already a suspect.' },
    { speaker: 'PHILOSOPHER', role: 'DEEP THINKER', text: 'For asking a question?' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'For making the question longer than necessary.' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'I have information.' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'What information?' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'Before the meeting started, I saw somebody near the notebook.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'Who?' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'I didn’t see the face clearly.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'Then how do you know it was somebody?' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'Detective, please. I know what I saw.' },
    { speaker: 'CHIBUIKE', role: 'SERIOUS READER', text: 'This is why people should read. If you had read the book, perhaps the missing page would make more sense.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'I read the menu.' },
    { speaker: 'CHIBUIKE', role: 'SERIOUS READER', text: 'There is no menu.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'Exactly. That is the problem.' },
    { speaker: 'NARRATOR', text: 'The play text supplied so far continues with the suspect interviews, the paper scrap, the food-container clue, the recording, and the President coming under pressure. The complete scene text will be added when the remaining script is supplied.' },
  ]},
  { act: 'ACT THREE', title: 'The Clues', subtitle: 'A quiet voice changes the direction of the case.', lines: [
    { speaker: 'NARRATOR', text: 'Just when the investigation seemed to be going nowhere, the Quiet Member finally spoke.' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'There is something nobody has asked.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'Go ahead.' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'Who moved the food container?' },
    { speaker: 'STAGE DIRECTION', text: 'Pause.', direction: true },
    { speaker: 'VICTOR', role: 'CHEF', text: 'What does the food container have to do with the missing page?' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'I don’t know yet. But I saw it beside the notebook earlier. Now it is on the other side of the table.' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'I told you someone was moving around!' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'Everybody remain calm. We have a new lead.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'Please be careful with the container. There is food inside.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'David, your relationship with food is interfering with justice.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'And your relationship with justice is interfering with lunch.' },
    { speaker: 'NARRATOR', text: 'The investigation continues through the clues and the recording. The remainder of Act Three will be completed from the full script.' },
  ]},
  { act: 'ACT FOUR', title: 'The Reveal', subtitle: 'The envelope marked OPEN AT THE END.', lines: [
    { speaker: 'NARRATOR', text: 'For a moment, nobody spoke. Then the Quiet Member reached for the envelope marked “OPEN AT THE END.”' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'Where did that envelope come from?' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'The Mystery Guest gave it to me before the meeting. I was told to keep it safe until the final activity.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'And you did not think this was relevant to our investigation?' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'You were busy interrogating the food lover.' },
    { speaker: 'DAVID', role: 'FOOD LOVER', text: 'Finally, someone understands my suffering.' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'I found the loose page beneath the food container. The edge had become damp, so I lifted it carefully and put it inside the envelope to keep it safe.' },
    { speaker: 'SAGE', role: 'PRESIDENT', text: 'You found the missing page?' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'Yes.' },
    { speaker: 'DETECTIVE SHARP', role: 'INVESTIGATOR', text: 'And you kept silent?' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'I was waiting for the right moment to explain. Then everybody started shouting.' },
    { speaker: 'MIRIAN', role: 'GOSSIP', text: 'So you knew the answer all along?' },
    { speaker: 'QUIET MEMBER', role: 'SILENT OBSERVER', text: 'I knew where the page was. I didn’t k…' },
    { speaker: 'STAGE DIRECTION', text: 'The supplied script cuts off at this point. The final reveal is intentionally marked incomplete until the remaining original text is provided.', direction: true },
  ]},
];

const clueCards = [
  { number: '01', title: 'The Paper Scrap', text: '“The ending belongs to whoever finds the page.”', note: 'Found beside a food container.', icon: FileText },
  { number: '02', title: 'The Food Container', text: 'It was beside the notebook. Then it moved.', note: 'The Quiet Member noticed the change.', icon: Search },
  { number: '03', title: 'The Recording', text: 'The Mystery Guest was standing beside the notebook.', note: 'The Content Creator may have captured more than expected.', icon: Eye },
  { number: '04', title: 'The Sealed Envelope', text: '“OPEN AT THE END.”', note: 'A final piece of the puzzle—do not open too early.', icon: Fingerprint },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState<'play'|'cast'|'case'>('play');
  const [activeScene, setActiveScene] = useState(0);
  const [character, setCharacter] = useState('ALL CHARACTERS');
  const [query, setQuery] = useState('');
  const [votes, setVotes] = useState<Record<string, number>>({});
  const [voted, setVoted] = useState<string | null>(null);
  const [showReveal, setShowReveal] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  const scene = scenes[activeScene];
  const filteredLines = useMemo(() => scene.lines.filter(line => {
    const matchesCharacter = character === 'ALL CHARACTERS' || line.speaker === character || (character === 'NARRATOR' && line.speaker === 'STAGE DIRECTION');
    const matchesQuery = !query || `${line.speaker} ${line.text}`.toLowerCase().includes(query.toLowerCase());
    return matchesCharacter && matchesQuery;
  }), [scene, character, query]);
  const totalVotes = Object.values(votes).reduce((a,b) => a+b, 0);

  function castVote(name: string) {
    if (voted) return;
    setVotes(prev => ({ ...prev, [name]: (prev[name] || 0) + 1 }));
    setVoted(name);
  }
  function jumpTo(tab: 'play'|'cast'|'case') { setActiveTab(tab); setMobileMenu(false); document.getElementById('experience')?.scrollIntoView({ behavior: 'smooth' }); }

  return <main>
    <nav className="topbar">
      <a className="brand" href="#top" aria-label="The Page Collective home"><span className="brand-mark"><BookOpen size={18}/></span><span>THE PAGE COLLECTIVE<span className="brand-small">.NG</span></span></a>
      <div className={`nav-links ${mobileMenu ? 'nav-open' : ''}`}>
        <button onClick={() => jumpTo('play')}>THE PLAY</button><button onClick={() => jumpTo('cast')}>THE CAST</button><button onClick={() => jumpTo('case')}>THE CASE FILE</button>
      </div>
      <button className="nav-cta" onClick={() => jumpTo('play')}>ENTER THE MYSTERY <ArrowRight size={15}/></button>
      <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu ? <X/> : <Menu/>}</button>
    </nav>

    <section className="hero" id="top">
      <div className="hero-grain"/><div className="hero-glow"/>
      <div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-line"/> AN ORIGINAL PAGE COLLECTIVE PRODUCTION <span className="eyebrow-line"/></div>
        <p className="presenter">THE PAGE COLLECTIVE.NG PRESENTS</p>
        <h1>THE LAST<br/><em>PAGE.</em></h1>
        <div className="hero-subtitle"><span className="subtitle-rule"/>WHO BETRAYED THE BOOK CLUB?</div>
        <p className="hero-description">Twelve readers. One missing page. A room full of suspects.<br/>Every story has an ending. This one has a secret.</p>
        <div className="hero-actions"><button className="button-primary" onClick={() => jumpTo('play')}>ENTER THE MYSTERY <ArrowRight size={17}/></button><button className="button-ghost" onClick={() => jumpTo('cast')}>MEET THE SUSPECTS <ArrowDown size={16}/></button></div>
        <div className="hero-meta"><span><Clapperboard size={15}/> MYSTERY-COMEDY TABLE READ</span><span className="meta-divider"/><span><Eye size={15}/> 12 READERS</span><span className="meta-divider"/><span><BookOpen size={15}/> 30–40 MIN</span></div>
      </div>
      <div className="hero-art" aria-label="Illustration of a mysterious book with a missing page"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-stamp">CASE<br/>NO. 001</div><div className="book-shadow"/><div className="book-object"><div className="book-cover"><div className="cover-top">THE PAGE COLLECTIVE</div><div className="cover-emblem"><BookOpen size={42} strokeWidth={1}/><span>✦</span></div><div className="cover-title">THE LAST<br/><i>PAGE</i></div><div className="cover-bottom">A STORY WITH A SECRET</div></div><div className="book-pages"/><div className="loose-page"><span>THE END</span><span className="page-lines"/><span className="page-lines short"/><span className="page-mark">?</span></div></div><div className="floating-note note-one"><span className="note-pin"/>THE PAGE IS MISSING.</div><div className="floating-note note-two"><Fingerprint size={14}/> EVIDENCE LOG / 01</div><div className="art-caption">SOME SECRETS ARE BETTER<br/>LEFT BETWEEN THE LINES.</div></div>
      <div className="hero-bottom"><span>AN AFTERNOON OF BOOKS, FOOD & SUSPICION</span><span>AWKA, ANAMBRA STATE <span className="gold-dot">●</span></span></div>
    </section>

    <section className="hook-strip"><div className="hook-icon"><ShieldQuestion size={24}/></div><div><span className="section-kicker">THE CASE AT A GLANCE</span><p>The final page of the club’s mystery story has vanished. <strong>Everyone has a story. Nobody has an alibi.</strong></p></div><div className="hook-stamp">READ.<br/>CONNECT.<br/>GROW.</div></section>

    <section className="experience-section" id="experience">
      <div className="section-heading"><div><span className="section-kicker">YOUR STORY. YOUR SUSPICIONS.</span><h2>Step inside<br/><em>the mystery.</em></h2></div><p>Read the play, meet the people behind the plot, and examine the clues. Just remember: the truth is on the last page.</p></div>
      <div className="experience-tabs"><button className={activeTab==='play'?'active':''} onClick={() => setActiveTab('play')}><BookOpen size={16}/> READ THE PLAY</button><button className={activeTab==='cast'?'active':''} onClick={() => setActiveTab('cast')}><Eye size={16}/> MEET THE CAST <span className="tab-count">12</span></button><button className={activeTab==='case'?'active':''} onClick={() => setActiveTab('case')}><Fingerprint size={16}/> CASE FILE <span className="tab-count">04</span></button></div>

      <AnimatePresence mode="wait">
        {activeTab==='play' && <motion.div key="play" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.22}} className="play-layout">
          <aside className="scene-sidebar"><span className="sidebar-label">TABLE OF CONTENTS</span>{scenes.map((s,i)=><button key={s.title} className={`scene-link ${activeScene===i?'selected':''}`} onClick={() => {setActiveScene(i);setCharacter('ALL CHARACTERS');setQuery('')}}><span className="scene-index">0{i+1}</span><span><small>{s.act}</small><strong>{s.title}</strong></span>{activeScene===i && <ArrowRight size={15}/>}</button>)}<div className="sidebar-note"><Sparkles size={16}/><p><strong>Reading tip</strong><br/>Choose your character to follow only their lines.</p></div></aside>
          <div className="script-panel"><div className="script-topline"><div><span className="section-kicker">{scene.act} / SCENE {activeScene+1}</span><h3>{scene.title}</h3><p>{scene.subtitle}</p></div><div className="script-symbol"><BookOpen size={26}/></div></div><div className="script-tools"><label className="character-select"><span>READ AS</span><select value={character} onChange={e=>setCharacter(e.target.value)}><option>ALL CHARACTERS</option>{characters.map(c=><option key={c.name}>{c.name}</option>)}</select><ChevronDown size={14}/></label><label className="script-search"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Find a line…"/><kbd>⌕</kbd></label></div><div className="script-content">{filteredLines.length ? filteredLines.map((line,i)=><div className={`dialogue ${line.direction?'stage-direction':''}`} key={`${activeScene}-${i}`}><div className="speaker-label">{line.direction ? 'STAGE DIRECTION' : line.speaker}{line.role && <small> — {line.role}</small>}</div><p>{line.direction ? <i>[{line.text}]</i> : line.text}</p></div>) : <div className="empty-state">No lines match your search in this scene.</div>}</div><div className="script-footer"><span>{filteredLines.length} LINES SHOWN <span className="gold-dot">●</span> {character==='ALL CHARACTERS'?'FULL SCENE':`READING AS ${character}`}</span><div className="scene-nav"><button disabled={activeScene===0} onClick={()=>{setActiveScene(v=>v-1);setQuery('')}}><ArrowLeft size={15}/> PREVIOUS</button><button disabled={activeScene===scenes.length-1} onClick={()=>{setActiveScene(v=>v+1);setQuery('')}}>NEXT SCENE <ArrowRight size={15}/></button></div></div></div>
        </motion.div>}

        {activeTab==='cast' && <motion.div key="cast" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.22}} className="cast-area"><div className="cast-intro"><span className="section-kicker">TWELVE READERS. TWELVE POSSIBILITIES.</span><h3>Everyone has<br/><em>something to hide.</em></h3><p>Meet the characters. Study their habits. Decide who you trust—before the story turns.</p></div><div className="cast-grid">{characters.map((c,i)=><article className="cast-card" key={c.name} style={{'--card-accent':c.color} as React.CSSProperties}><div className="cast-card-top"><span className="cast-number">SUSPECT FILE / 0{i+1}</span><span className="cast-initials">{c.initials}</span></div><div className="cast-portrait"><div className="portrait-ring"/><span>{c.initials}</span><Fingerprint className="portrait-mark" size={25}/></div><h4>{c.name}</h4><span className="cast-role">{c.role}</span><p>{c.description}</p><div className="cast-card-bottom"><span>PERSON OF INTEREST</span><span className="status-dot"/></div></article>)}</div></motion.div>}

        {activeTab==='case' && <motion.div key="case" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.22}} className="case-area"><div className="case-header"><div><span className="section-kicker">CONFIDENTIAL / EVIDENCE ROOM</span><h3>The case<br/><em>file.</em></h3><p>Every clue tells part of the story. None tells the whole truth.</p></div><div className="case-file-stamp">OPEN<br/>INVESTIGATION</div></div><div className="clue-grid">{clueCards.map((clue,i)=>{const Icon=clue.icon;return <article className="clue-card" key={clue.number}><div className="clue-card-top"><span>EXHIBIT {clue.number}</span><Icon size={21}/></div><h4>{clue.title}</h4><blockquote>{clue.text}</blockquote><p>{clue.note}</p><div className="clue-card-bottom"><span>STATUS: LOGGED</span><span>0{i+1} / 04</span></div></article>})}</div><div className="vote-panel"><div className="vote-copy"><span className="section-kicker">AUDIENCE PARTICIPATION / 01</span><h3>Who looks<br/><em>most suspicious?</em></h3><p>Cast your suspicion. You can vote once on this device. The results below are local to this browser session.</p><div className="vote-total">{totalVotes.toString().padStart(2,'0')} <span>VOTES RECORDED</span></div></div><div className="vote-options">{['SAGE','MIRIAN','VICTOR','DAVID','LATECOMER','PHILOSOPHER','QUIET MEMBER','MYSTERY GUEST','SOMEONE ELSE'].map(name=><button key={name} className={`vote-option ${voted===name?'chosen':''}`} onClick={()=>castVote(name)} disabled={!!voted}><span>{name}</span>{voted ? <><span className="vote-percent">{totalVotes?Math.round(((votes[name]||0)/totalVotes)*100):0}%</span><span className="vote-bar"><i style={{width:`${totalVotes?((votes[name]||0)/totalVotes)*100:0}%`}}/></span></> : <span className="vote-circle"/>}</button>)}{voted && <div className="vote-thanks"><Check size={16}/> Your suspicion has been recorded. Detective Sharp has been notified. (Probably.)</div>}</div></div></motion.div>}
      </AnimatePresence>
    </section>

    <section className="reveal-section"><div className="reveal-text"><span className="section-kicker">EVERY STORY HAS AN ENDING</span><h2>But can you<br/>trust <em>yours?</em></h2><p>You have heard the witnesses. Examined the clues. Questioned the suspects. There is only one thing left to do.</p><button className="button-primary" onClick={()=>setShowReveal(true)}>OPEN THE ENVELOPE <ArrowRight size={16}/></button><small>WARNING: THE SUPPLIED SCRIPT'S FINAL REVEAL IS INCOMPLETE.</small></div><div className="envelope-scene"><div className="envelope-glow"/><div className="envelope"><div className="envelope-back"/><div className="envelope-paper"><span>THE LAST PAGE</span><i>THE TRUTH IS INSIDE</i></div><div className="envelope-front"/><div className="envelope-flap"/><div className="wax-seal">PC</div></div><span className="envelope-label">OPEN AT THE END</span></div></section>

    <section className="motto-band"><div className="motto-book"><BookOpen size={27}/></div><div><span>THE PAGE COLLECTIVE.NG</span><h2>Read. <em>Connect.</em> Grow.</h2></div><p>More than a reading community.<br/>A place for stories, people, and possibility.</p></section>
    <footer><a className="brand footer-brand" href="#top"><span className="brand-mark"><BookOpen size={17}/></span><span>THE PAGE COLLECTIVE<span className="brand-small">.NG</span></span></a><span className="footer-credit">AN ORIGINAL TABLE-READING PLAY EXPERIENCE</span><a className="back-top" href="#top">BACK TO THE BEGINNING ↑</a></footer>

    <AnimatePresence>{showReveal && <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setShowReveal(false)}><motion.div className="reveal-modal" initial={{opacity:0,y:20,scale:.97}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:12}} onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowReveal(false)} aria-label="Close"><X size={20}/></button><div className="modal-seal"><BookOpen size={28}/></div><span className="section-kicker">SEALED EVIDENCE / FINAL PAGE</span><h3>The truth is<br/><em>almost here.</em></h3><p>The script supplied to build this experience ends mid-sentence during the final reveal. Send the remaining pages to complete this ending without inventing or changing the story.</p><div className="modal-note"><FileText size={17}/><span>ENDING STATUS: WAITING FOR THE COMPLETE ORIGINAL SCRIPT</span></div><button className="button-primary" onClick={()=>setShowReveal(false)}>RETURN TO THE CASE <ArrowRight size={16}/></button></motion.div></motion.div>}</AnimatePresence>
  </main>;
}
